# Exception Handler

This package provides simple exception handling utilities for Python applications.
